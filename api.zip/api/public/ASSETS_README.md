# Required Assets

Please add the following assets to this directory:

1. **starnoise.svg** - Background image for the space theme
2. **nasalization.otf** - Font file for titles and highlighted text
3. **logo.png** - Logo image used for favicon and branding

These assets are referenced in `index.html` and `styles.css`.

